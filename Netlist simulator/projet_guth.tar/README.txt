Le code source est situé dans les fichiers :
 - nls.ml       : l'interpréteur en lui-même
 - graph.ml     : recherche de cycle et tri topologique
 - scheduler.ml : application du tri topologique à la net-list

Le rapport contenant les choix effectués et l'implémentation choisie est dans le
fichier rapport.pdf

Pour compiler, lancer "ocamlbuild nls.byte" suffit. Le fichier nls.byte présent
dans l'archive correspond au résultat de la commande précédente.

Le programme se lance avec la commande "./nls.byte netlist.net" où netlist.net
est le chemin de la net-list à tester. Il prend également un argument optionnel
"-n nb" qui indique que la net-list doit être évaluée sur nb cycles.
